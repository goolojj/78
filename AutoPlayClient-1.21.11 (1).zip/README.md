# AutoPlayClient (Minecraft 1.21.11 Fabric Mod)

One-button AI Autoplay client mod for **Minecraft Java Edition 1.21.11** (Fabric).

## Controls
- **`M` Key**: Toggle AI Autoplay **ON / OFF**
- **`N` Key**: Cycle AI Mode (`AUTO AI` -> `TREE FARM` -> `MINING` -> `BUILD HOUSE` -> `COMBAT ONLY`)

## Features
- **Auto Tree Chopping**: Finds nearby logs, walks over, equips axe if available, and mines wood.
- **Auto House Builder**: Builds a 5x5x4 starter shelter (walls, doorway, roof) once you have blocks in your hotbar.
- **Auto Mining**: Finds nearby ores (coal, iron, copper, gold, diamond) or stone, equips pickaxe, and mines.
- **Night Combat & Defense**: Automatically equips sword/axe and fights nearby zombies, skeletons, and spiders with proper attack cooldown.
- **Creeper Retreat**: Detects creepers nearby and retreats so your player and house stay safe.
- **Auto-Eat**: Eats food from your hotbar automatically when health or hunger drops.
- **On-Screen HUD**: Shows live status (`ON/OFF`), active mode, and current AI task in the top-left corner.

## How to Build `.jar` Using GitHub Actions (No PC Setup Needed)
1. Create a new repository on GitHub.
2. Upload all files from this ZIP (make sure `.github/workflows/main.yml` is included).
3. Open the **Actions** tab in your GitHub repository.
4. Click **Build AutoPlayClient JAR (1.21.11)** -> wait ~2 minutes for the green checkmark.
5. Download **`AutoPlayClient-1.21.11-Mod-JAR`** from the Artifacts section and put the `.jar` into your `.minecraft/mods` folder (along with Fabric API for 1.21.11).
