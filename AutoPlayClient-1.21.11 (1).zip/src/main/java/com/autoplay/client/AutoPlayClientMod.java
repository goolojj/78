package com.autoplay.client;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.text.Text;
import org.lwjgl.glfw.GLFW;

public class AutoPlayClientMod implements ClientModInitializer {
    public static final String MOD_ID = "autoplayclient";

    private static KeyBinding toggleKey;
    private static KeyBinding modeKey;
    private static final AutoPlayEngine ENGINE = new AutoPlayEngine();

    public static AutoPlayEngine getEngine() {
        return ENGINE;
    }

    @Override
    public void onInitializeClient() {
        toggleKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.autoplayclient.toggle",
                GLFW.GLFW_KEY_M,
                KeyBinding.Category.GAMEPLAY
        ));

        modeKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.autoplayclient.mode",
                GLFW.GLFW_KEY_N,
                KeyBinding.Category.GAMEPLAY
        ));

        AutoPlayHud.register();

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            while (toggleKey.wasPressed()) {
                boolean nowEnabled = ENGINE.toggle(client);
                if (client.player != null) {
                    client.player.sendMessage(
                            Text.literal(nowEnabled
                                    ? "\u00A7a[AutoPlay AI] ON \u00A77(Mode: " + ENGINE.getMode().label + ")"
                                    : "\u00A7c[AutoPlay AI] OFF"),
                            true
                    );
                }
            }

            while (modeKey.wasPressed()) {
                AutoPlayEngine.Mode nextMode = ENGINE.cycleMode();
                if (client.player != null) {
                    client.player.sendMessage(
                            Text.literal("\u00A7b[AutoPlay AI] Mode: \u00A7f" + nextMode.label),
                            true
                    );
                }
            }

            ENGINE.tick(client);
        });
    }
}
